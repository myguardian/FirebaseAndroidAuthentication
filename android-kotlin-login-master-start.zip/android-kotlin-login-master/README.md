Implementing Login on Android with FirebaseUI
ToStart project
=========================

